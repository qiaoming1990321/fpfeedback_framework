//
//  FPFamilyKDCycleBannerView.h
//  FPFamilyKDCycleBannerViewDemo
//
//  Created by Kingiol on 14-4-11.
//  Copyright (c) 2014年 Kingiol. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FPFamilyKDCycleBannerView;

typedef void(^CompleteBlock)(void);

@protocol FPFamilyKDCycleBannerViewDataource <NSObject>

@required
- (NSArray *)numberOfFPFamilyKDCycleBannerView:(FPFamilyKDCycleBannerView *)bannerView;
- (UIViewContentMode)contentModeForImageIndex:(NSUInteger)index;

@optional
- (UIImage *)placeHolderImageOfZeroBannerView;
- (UIImage *)placeHolderImageOfBannerView:(FPFamilyKDCycleBannerView *)bannerView atIndex:(NSUInteger)index;

@end

@protocol FPFamilyKDCycleBannerViewDelegate <NSObject>

@optional
- (void)cycleBannerView:(FPFamilyKDCycleBannerView *)bannerView didScrollToIndex:(NSUInteger)index;
- (void)cycleBannerView:(FPFamilyKDCycleBannerView *)bannerView didSelectedAtIndex:(NSUInteger)index;

@end

@interface FPFamilyKDCycleBannerView : UIView

// Delegate and Datasource
@property (weak, nonatomic) IBOutlet id<FPFamilyKDCycleBannerViewDataource> datasource;
@property (weak, nonatomic) IBOutlet id<FPFamilyKDCycleBannerViewDelegate> delegate;

@property (assign, nonatomic, getter = isContinuous) BOOL continuous;   // if YES, then bannerview will show like a carousel, default is NO
@property (assign, nonatomic) NSUInteger autoPlayTimeInterval;  // if autoPlayTimeInterval more than 0, the bannerView will autoplay with autoPlayTimeInterval value space, default is 0
// 轮播图的内边距
@property (assign, nonatomic) UIEdgeInsets contentEdgeInsets;
// 轮播图的投影
@property (strong, nonatomic) UIColor *shadowColor;

- (void)reloadDataWithCompleteBlock:(CompleteBlock)competeBlock;
- (void)setCurrentPage:(NSInteger)currentPage animated:(BOOL)animated;

@end
