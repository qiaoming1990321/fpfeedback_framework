//
//  FPFamilyFeedBackAppListMenuView.h
//  feedback
//
//  Created by 李焱 on 2021/3/25.
//

#import <UIKit/UIKit.h>
#import "FPFamilyFeedbackProductBean.h"
#import "UIColor+FPFamilyHex.h"
#import <Masonry/Masonry.h>
#import "FPFamilyFeedBackCollectionViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@protocol FPFamilyFeedBackAppListMenuViewDelegate <NSObject>

- (void)chooseProductResult:(FPFamilyFeedbackProductBean*)bean;

@end

@interface FPFamilyFeedBackAppListMenuView : UIView

@property(nonatomic, strong) UICollectionView *collectionView;
@property(nonatomic, weak) id<FPFamilyFeedBackAppListMenuViewDelegate> delegate;

- (void)showWithList:(NSArray *)list;
- (void)hide;
- (BOOL)isShow;
- (void)screenOrientationChange:(CGRect)rect;

@end

NS_ASSUME_NONNULL_END
