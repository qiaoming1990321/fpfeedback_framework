//
//  FPFamilyProductQRView.h
//  Feedback
//
//  Created by 李焱 on 2021/4/23.
//

#import <UIKit/UIKit.h>
#import "FPFamilyFeedbackStoreModuleBean.h"

NS_ASSUME_NONNULL_BEGIN

@protocol FPFamilyProductQRViewDelegate <NSObject>

- (void)qrSkipAppStoreClick:(NSString *)appId;

@end

@interface FPFamilyProductQRView : UIView

@property(nonatomic, weak) id<FPFamilyProductQRViewDelegate> delegate;

- (void)setupProductBean:(FPFamilyFeedbackStoreModuleBean *)bean;

@end

NS_ASSUME_NONNULL_END
