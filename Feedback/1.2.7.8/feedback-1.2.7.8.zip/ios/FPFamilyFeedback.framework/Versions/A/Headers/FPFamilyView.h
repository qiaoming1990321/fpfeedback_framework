//
//  FPFamilyView.h
//  Feedback
//
//  Created by 李焱 on 2021/4/12.
//

#import <UIKit/UIKit.h>
#import "FPFamilyViewController.h"

NS_ASSUME_NONNULL_BEGIN

@protocol FPFamilyViewDelegate <NSObject>

- (void)closeBtnClick;
- (void)shareBtnClick;
- (void)adviseBtnClick;
- (void)skipAppStoreClick:(NSString *)appId;

- (void)openAppClick:(FPFamilyFeedbackStoreModuleBean *)bean;
- (void)skipToAppSoreClick:(FPFamilyFeedbackStoreModuleBean *)bean;
- (void)qrSkipAppStoreClick:(NSString *)appId;

@end

@interface FPFamilyView : UIView

@property(nonatomic, weak) id<FPFamilyViewDelegate> delegate;

- (void)setupStoreModuleData:(NSArray *)beans;
- (void)screenOrientationChange:(CGRect)rect;
@end

NS_ASSUME_NONNULL_END
