//
//  FPFamilyFeedBackSdk.h
//  feedback
//
//  Created by 李焱 on 2021/3/23.
//

#import <Foundation/Foundation.h>
#import "FPFamilyFeedBackParams.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^ParamsCallBack)(FPFamilyFeedBackParams*);

@interface FPFamilyFeedBackSdk : NSObject

@property(nonatomic, strong) FPFamilyFeedBackParams *params;

+(instancetype)shareInstance;
- (void)setup:(FPFamilyFeedBackParams *)params;
- (void)updateParams:(ParamsCallBack)callBack;
- (void)showInController:(UIViewController *)vc needFamily:(BOOL)needFamily;

- (void)setupEnvironment:(BOOL)isDebug;
- (void)setupModuleId:(NSInteger)moduleId;

@end

NS_ASSUME_NONNULL_END
