//
//  FPFamilyViewController.h
//  AFNetworking
//
//  Created by 李焱 on 2021/4/9.
//

#import <UIKit/UIKit.h>
#import "FPFamilyViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface FPFamilyViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
