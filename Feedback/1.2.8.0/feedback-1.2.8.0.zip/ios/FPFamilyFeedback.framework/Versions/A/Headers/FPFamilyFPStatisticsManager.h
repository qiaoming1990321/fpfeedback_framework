//
//  FPFamilyFPStatisticsManager.h
//  Feedback
//
//  Created by admin on 2021/6/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FPFamilyFPStatisticsManager : NSObject
+ (FPFamilyFPStatisticsManager *(^)(void))initObject;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))operationCode;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))funcId;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))protocol;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))statisticsObject;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))associationObject;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))entrance;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))tab;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))orderType;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))remark;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))remarkOne;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))remarkTwo;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))position;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))orderId;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))resultCode;

- (FPFamilyFPStatisticsManager * (^)(NSString *str))advertId;

- (void (^)(void))upload104NoTypeStatics;
@end

NS_ASSUME_NONNULL_END
