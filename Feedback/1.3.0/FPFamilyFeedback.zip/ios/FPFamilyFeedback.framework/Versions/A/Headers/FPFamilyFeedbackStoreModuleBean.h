//
//  FPFamilyFeedbackStoreModuleBean.h
//  Feedback
//
//  Created by 李焱 on 2021/4/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FPFamilyFeedbackStoreModuleBean : NSObject

@property(nonatomic, strong) NSString *moduleId;

@property(nonatomic, strong) NSString *title;

@property(nonatomic, strong) NSString *appId;

@property(nonatomic, strong) NSString *desc;

@property(nonatomic, strong) NSString *skipUrl;

@property(nonatomic, strong) NSArray *publicityPicUrl;

@property(nonatomic, strong) NSString *logoUrl;

@property(nonatomic, assign) NSInteger layout;

@property(nonatomic, strong) NSString *originalCopywritingString;
//非服务器返回字段
//是否安装过
@property(nonatomic, assign) BOOL hasInstall;
//当前tab是否可以自动轮播
@property(nonatomic, assign) BOOL currentPageCanAutoScroll;
//轮播停止时候 记录当前的index
@property(nonatomic, assign) NSInteger currentPage;
@property(nonatomic, assign) NSInteger totalPage;
+ (NSArray *)transforModuleBeans:(NSData *)data;

- (BOOL)isShowQRDialog;

@end

NS_ASSUME_NONNULL_END
