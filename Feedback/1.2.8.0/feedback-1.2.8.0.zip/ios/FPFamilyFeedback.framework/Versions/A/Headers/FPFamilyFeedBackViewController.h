//
//  FPFamilyFeedBackViewController.h
//  feedback
//
//  Created by 李焱 on 2021/3/18.
//

#import <UIKit/UIKit.h>
#import "FPFamilyFeedBackView.h"
#import "FPFamilyFeedBackModel.h"
#import "FPFamilyFeedBackBean.h"
#import <MBProgressHUD/MBProgressHUD.h>
#import "FPFamilyFeedbackProductBean.h"
#import "FPFamilyFeedBackTopicBean.h"
#import "FPFamilyFeedBackSdk.h"

NS_ASSUME_NONNULL_BEGIN

@interface FPFamilyFeedBackViewController : UIViewController

@property(nonatomic, assign) BOOL needFamily;
@property(nonatomic, strong) FPFamilyFeedBackView *feedBackView;
@property(nonatomic, strong) FPFamilyFeedBackModel *model;
@property(nonatomic, strong, nullable) UIImage * image;
@property(nonatomic, strong) FPFamilyFeedbackProductBean *productBean;
@property(nonatomic, strong) FPFamilyFeedBackTopicBean *topicBean;

- (void)initSubView;

@end

NS_ASSUME_NONNULL_END
