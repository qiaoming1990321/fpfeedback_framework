//
//  FPFamilyProductItemCell.h
//  Feedback
//
//  Created by 李焱 on 2021/4/12.
//

#import <UIKit/UIKit.h>
#import "FPFamilyFeedbackStoreModuleBean.h"

NS_ASSUME_NONNULL_BEGIN

@protocol FPFamilyProductItemCellDelegate <NSObject>

- (void)skipStoreClick:(FPFamilyFeedbackStoreModuleBean *)bean;

@end

@interface FPFamilyProductItemCell : UICollectionViewCell

@property(nonatomic, weak) id<FPFamilyProductItemCellDelegate> delegate;

- (void)setupBean:(FPFamilyFeedbackStoreModuleBean *)bean;

@end

NS_ASSUME_NONNULL_END
