//
//  FPFamilyFeedBackCollectionViewCell.h
//  feedback
//
//  Created by 李焱 on 2021/3/26.
//

#import <UIKit/UIKit.h>
#import "FPFamilyFeedbackProductBean.h"
#import "FPFamilyFeedBackTopicBean.h"
#import "UIColor+FPFamilyHex.h"
#import <Masonry/Masonry.h>

NS_ASSUME_NONNULL_BEGIN

@interface FPFamilyFeedBackCollectionViewCell : UICollectionViewCell

- (void)updateCell:(id)bean;

@end

NS_ASSUME_NONNULL_END
