//
//  FPFamilyProductCollectionView.h
//  Feedback
//
//  Created by 李焱 on 2021/4/12.
//

#import <UIKit/UIKit.h>
#import "FPFamilyFeedbackStoreModuleBean.h"

NS_ASSUME_NONNULL_BEGIN

@protocol FPFamilyProductCollectionViewDelegate <NSObject>

- (void)skipAppStoreClick:(FPFamilyFeedbackStoreModuleBean *)bean;
- (void)scrollDistance:(CGFloat)distance withHeaderHeight:(CGFloat)height;

@end

@interface FPFamilyProductCollectionView : UICollectionView

@property(nonatomic, strong) NSArray *moduleBeans;
@property(nonatomic, weak) id<FPFamilyProductCollectionViewDelegate> customDelegate;
@property(nonatomic, assign) BOOL isLandScape;

@end

NS_ASSUME_NONNULL_END
