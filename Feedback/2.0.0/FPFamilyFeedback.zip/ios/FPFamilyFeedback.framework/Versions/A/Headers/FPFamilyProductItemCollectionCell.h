//
//  FPFamilyProductItemCollectionCell.h
//  FPFamilyFeedback
//
//  Created by qiaoming on 2021/6/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FPFamilyProductItemCollectionCell : UICollectionViewCell

@property(nonatomic, strong) UIImageView *iconImageView;
-(void)loadImage:(NSString *)urlstr;
@end

NS_ASSUME_NONNULL_END
